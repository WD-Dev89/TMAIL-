<main class="page flex-1 p-5">
    {!! $page->content !!}
</main>
