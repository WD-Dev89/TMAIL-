<main class="flex-1 page p-5">
    {!! $page->content !!}
</main>
